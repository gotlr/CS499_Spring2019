int my_mean_C(int*, int, double*);

#define MY_MEAN_ERROR_NO_DATA 1
